﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankappdatabase
{
    public partial class Admin_form : Form
    {
        List<Account> account;
        public Admin_form()
        {          
            InitializeComponent();
            account = AccountDataBase.getAccountList();
            load();
        }

        private void Admin_form_Load(object sender, EventArgs e)
        {

        }
       
        private void btn_Update_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Update this account?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result != DialogResult.Yes) { return; }
            else
            {
                Image im =pic_user.Image;
                byte[] imagedata;
                MemoryStream ms = new MemoryStream();
                im.Save(ms, im.RawFormat);
                imagedata = ms.ToArray();
             double balance= Convert.ToDouble(  txt_balance.Text);
              int acc_id = Convert.ToInt32(txt_account_id.Text);
                AccountDataBase.uppdateuser(txt_address.Text, imagedata, txt_city.Text, txt_phone.Text, txt_email.Text, txt_gender.Text, balance, acc_id);
                if (true)
                {
                    MessageBox.Show("Update Succefully");
                    account = AccountDataBase.getAccountList();
                    load();
                }
                else
                {
                    MessageBox.Show("Error to update");
                }
            }
        }
        public void load()
        {     
                DataTable dt = new DataTable();
                dt.Columns.Add("USER_ID", typeof(int));
                dt.Columns.Add("FIRST_NAME", typeof(string));
                dt.Columns.Add("LAST_NAME", typeof(string));
                dt.Columns.Add("PHONE", typeof(string));
                dt.Columns.Add("EMAIL", typeof(string));
                dt.Columns.Add("GENDER", typeof(string));
                dt.Columns.Add("ADDRESS", typeof(string));
                dt.Columns.Add("CITY", typeof(string));
                dt.Columns.Add("CNIC", typeof(string));
                dt.Columns.Add("BALANCE", typeof(double));
                dt.Columns.Add("IMAGE", typeof(Image));                
                for (int i = 0; i < account.Count; i++)
                { 
                    dt.Rows.Add(
                        account[i].GetUser_id(),
                         account[i].getFirst_name(),
                         account[i].getLast_name(),
                         account[i].getPhone(),
                         account[i].getEmail(),
                         account[i].getGender(),
                         account[i].getAddress(),
                         account[i].getCity(),
                         account[i].getCnic(),
                         account[i].getbalance(),
                         account[i].GetImage()
                    );
                }
                 grd_user.DataSource = dt;            
            }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_account_id.Text))
            {
                MessageBox.Show("Please select a record to delete.");
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this account?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result != DialogResult.Yes) { return; }
            else
            {
                int account_id = Convert.ToInt32(txt_account_id.Text);
                AccountDataBase.deleteAccount(account_id);
                    if (true)
                    {
                    MessageBox.Show("Account delete Successfully");
                    account = AccountDataBase.getAccountList();
                    load();
                    }
                else
                {
                    MessageBox.Show("Error To delete"); 
                }
            }
        }
        private void grd_user_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            pic_user.Image = null;
           
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = grd_user.Rows[e.RowIndex];
                txt_account_id.Text = selectedRow.Cells["user_id"].Value.ToString();
                txt_address.Text = selectedRow.Cells["address"].Value.ToString();
                txt_balance.Text = selectedRow.Cells["balance"].Value.ToString();
                txt_city.Text = selectedRow.Cells["city"].Value.ToString();
                txt_cnic.Text = selectedRow.Cells["cnic"].Value.ToString();
                txt_email.Text = selectedRow.Cells["email"].Value.ToString();
                txt_first_name.Text = selectedRow.Cells["first_name"].Value.ToString();
                txt_gender.Text = selectedRow.Cells["gender"].Value.ToString();
                txt_last_name.Text = selectedRow.Cells["last_name"].Value.ToString();
                txt_phone.Text = selectedRow.Cells["phone"].Value.ToString();
                pic_user.Image = (Image)selectedRow.Cells["IMAGE"].Value;
            }
           
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
      

        private void pic_user_Click(object sender, EventArgs e)
        {
           
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                pic_user.Image = Image.FromFile(dialog.FileName);                           

            }
        }

        private void btn_money_Click(object sender, EventArgs e)//serch button
        {

            string keyword = txt_search.Text.Trim();

            // Try to get the DataView safely
            DataView dv = null;

            if (grd_user.DataSource is DataTable)
            {
                dv = ((DataTable)grd_user.DataSource).DefaultView;
            }
            else if (grd_user.DataSource is DataView)
            {
                dv = (DataView)grd_user.DataSource;
            }


            if (string.IsNullOrEmpty(keyword))
            {
                dv.RowFilter = ""; // Clear filter
            }
            else
            {
                // Apply filter (case-insensitive match)
                dv.RowFilter = $"FIRST_NAME LIKE '%{keyword}%' " +
                               $"OR LAST_NAME LIKE '%{keyword}%' " +
                               $"OR CNIC LIKE '%{keyword}%' " +
                               $"OR PHONE LIKE '%{keyword}%' " +
                               $"OR Convert(USER_ID, 'System.String') LIKE '%{keyword}%'";
            }

            grd_user.DataSource = dv;

        }

        private void btn_home_Click(object sender, EventArgs e)
        {
          
            loginForm l = new loginForm();
            l.Show();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
