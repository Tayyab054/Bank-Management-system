﻿namespace bankappdatabase
{
    partial class User_dash_board
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User_dash_board));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_account = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_user_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.user_ACCOUNT = new System.Windows.Forms.Label();
            this.txt_user_account_id = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lab_ammount = new System.Windows.Forms.Label();
            this.pan_balance = new System.Windows.Forms.Panel();
            this.pan__send_dash = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_send_name = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_send = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_send_ammount = new System.Windows.Forms.TextBox();
            this.txt_send_account = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_account2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pan_hestory = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.grd_user_history = new System.Windows.Forms.DataGridView();
            this.pic_history = new System.Windows.Forms.PictureBox();
            this.pan_money_send = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pan_balance.SuspendLayout();
            this.pan__send_dash.SuspendLayout();
            this.pan_hestory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd_user_history)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_history)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PowderBlue;
            this.panel1.Controls.Add(this.btn_account);
            this.panel1.Controls.Add(this.btn_home);
            this.panel1.Controls.Add(this.btn_back);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1301, 89);
            this.panel1.TabIndex = 26;
            // 
            // btn_account
            // 
            this.btn_account.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_account.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_account.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btn_account.Location = new System.Drawing.Point(951, 31);
            this.btn_account.Name = "btn_account";
            this.btn_account.Size = new System.Drawing.Size(108, 35);
            this.btn_account.TabIndex = 74;
            this.btn_account.Text = "Accounts";
            this.btn_account.UseVisualStyleBackColor = true;
            this.btn_account.Click += new System.EventHandler(this.btn_account_Click);
            // 
            // btn_home
            // 
            this.btn_home.BackgroundImage = global::bankappdatabase.Properties.Resources.Screenshot_2025_04_29_213219_removebg_preview;
            this.btn_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_home.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.btn_home.Location = new System.Drawing.Point(1086, 31);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(90, 35);
            this.btn_home.TabIndex = 73;
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // btn_back
            // 
            this.btn_back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_back.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btn_back.Location = new System.Drawing.Point(1203, 31);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(90, 35);
            this.btn_back.TabIndex = 67;
            this.btn_back.Text = "Exit";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(24, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Location = new System.Drawing.Point(119, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Global Bank ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label4.Location = new System.Drawing.Point(159, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 29);
            this.label4.TabIndex = 38;
            this.label4.Text = "Rs=";
            // 
            // txt_user_name
            // 
            this.txt_user_name.BackColor = System.Drawing.Color.Snow;
            this.txt_user_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_user_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_user_name.ForeColor = System.Drawing.Color.SteelBlue;
            this.txt_user_name.Location = new System.Drawing.Point(142, 116);
            this.txt_user_name.Name = "txt_user_name";
            this.txt_user_name.ReadOnly = true;
            this.txt_user_name.Size = new System.Drawing.Size(156, 24);
            this.txt_user_name.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label2.Location = new System.Drawing.Point(12, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 29);
            this.label2.TabIndex = 39;
            this.label2.Text = "User Name";
            // 
            // user_ACCOUNT
            // 
            this.user_ACCOUNT.AutoSize = true;
            this.user_ACCOUNT.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_ACCOUNT.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.user_ACCOUNT.Location = new System.Drawing.Point(12, 157);
            this.user_ACCOUNT.Name = "user_ACCOUNT";
            this.user_ACCOUNT.Size = new System.Drawing.Size(122, 29);
            this.user_ACCOUNT.TabIndex = 70;
            this.user_ACCOUNT.Text = "Account ID";
            // 
            // txt_user_account_id
            // 
            this.txt_user_account_id.BackColor = System.Drawing.Color.Snow;
            this.txt_user_account_id.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_user_account_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_user_account_id.ForeColor = System.Drawing.Color.SteelBlue;
            this.txt_user_account_id.Location = new System.Drawing.Point(142, 162);
            this.txt_user_account_id.Name = "txt_user_account_id";
            this.txt_user_account_id.ReadOnly = true;
            this.txt_user_account_id.Size = new System.Drawing.Size(156, 24);
            this.txt_user_account_id.TabIndex = 69;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Candara", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label16.Location = new System.Drawing.Point(160, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(135, 19);
            this.label16.TabIndex = 122;
            this.label16.Text = "👤Currunt Balance!";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Candara", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Teal;
            this.label11.Location = new System.Drawing.Point(1094, 600);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 19);
            this.label11.TabIndex = 125;
            this.label11.Text = "© 2025 Global Bank";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Candara", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Teal;
            this.label12.Location = new System.Drawing.Point(557, 600);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(186, 19);
            this.label12.TabIndex = 124;
            this.label12.Text = " 💬 24/7 Customer Support ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Candara", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Teal;
            this.label13.Location = new System.Drawing.Point(20, 600);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(245, 19);
            this.label13.TabIndex = 123;
            this.label13.Text = "  🔒 Secure & Encrypted Transactions ";
            // 
            // lab_ammount
            // 
            this.lab_ammount.AutoSize = true;
            this.lab_ammount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lab_ammount.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_ammount.ForeColor = System.Drawing.Color.DarkRed;
            this.lab_ammount.Location = new System.Drawing.Point(203, 57);
            this.lab_ammount.Name = "lab_ammount";
            this.lab_ammount.Size = new System.Drawing.Size(30, 19);
            this.lab_ammount.TabIndex = 128;
            this.lab_ammount.Text = "0.0";
            // 
            // pan_balance
            // 
            this.pan_balance.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pan_balance.Controls.Add(this.label16);
            this.pan_balance.Controls.Add(this.lab_ammount);
            this.pan_balance.Controls.Add(this.label4);
            this.pan_balance.Location = new System.Drawing.Point(400, 138);
            this.pan_balance.Name = "pan_balance";
            this.pan_balance.Size = new System.Drawing.Size(531, 100);
            this.pan_balance.TabIndex = 129;
            // 
            // pan__send_dash
            // 
            this.pan__send_dash.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pan__send_dash.Controls.Add(this.panel7);
            this.pan__send_dash.Controls.Add(this.label8);
            this.pan__send_dash.Controls.Add(this.txt_send_name);
            this.pan__send_dash.Controls.Add(this.panel6);
            this.pan__send_dash.Controls.Add(this.panel5);
            this.pan__send_dash.Controls.Add(this.panel4);
            this.pan__send_dash.Controls.Add(this.btn_send);
            this.pan__send_dash.Controls.Add(this.label7);
            this.pan__send_dash.Controls.Add(this.txt_send_ammount);
            this.pan__send_dash.Controls.Add(this.txt_send_account);
            this.pan__send_dash.Controls.Add(this.label6);
            this.pan__send_dash.Controls.Add(this.label3);
            this.pan__send_dash.Controls.Add(this.txt_account2);
            this.pan__send_dash.Controls.Add(this.label5);
            this.pan__send_dash.Location = new System.Drawing.Point(17, 195);
            this.pan__send_dash.Name = "pan__send_dash";
            this.pan__send_dash.Size = new System.Drawing.Size(362, 362);
            this.pan__send_dash.TabIndex = 130;
            this.pan__send_dash.Visible = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkRed;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel7.Location = new System.Drawing.Point(149, 274);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(184, 3);
            this.panel7.TabIndex = 137;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Candara", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(17, 254);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 23);
            this.label8.TabIndex = 136;
            this.label8.Text = "Name ";
            // 
            // txt_send_name
            // 
            this.txt_send_name.BackColor = System.Drawing.Color.DarkSlateGray;
            this.txt_send_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_send_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_send_name.ForeColor = System.Drawing.Color.DarkCyan;
            this.txt_send_name.Location = new System.Drawing.Point(149, 246);
            this.txt_send_name.Name = "txt_send_name";
            this.txt_send_name.Size = new System.Drawing.Size(184, 24);
            this.txt_send_name.TabIndex = 135;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkRed;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel6.Location = new System.Drawing.Point(149, 219);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(184, 3);
            this.panel6.TabIndex = 134;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkRed;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel5.Location = new System.Drawing.Point(35, 147);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(288, 3);
            this.panel5.TabIndex = 133;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkRed;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel4.Location = new System.Drawing.Point(35, 86);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(288, 3);
            this.panel4.TabIndex = 132;
            // 
            // btn_send
            // 
            this.btn_send.BackColor = System.Drawing.Color.Transparent;
            this.btn_send.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_send.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_send.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_send.Location = new System.Drawing.Point(254, 313);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(90, 35);
            this.btn_send.TabIndex = 131;
            this.btn_send.Text = "Send";
            this.btn_send.UseVisualStyleBackColor = false;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Candara", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(17, 199);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 23);
            this.label7.TabIndex = 130;
            this.label7.Text = "Add Ammount";
            // 
            // txt_send_ammount
            // 
            this.txt_send_ammount.BackColor = System.Drawing.Color.DarkSlateGray;
            this.txt_send_ammount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_send_ammount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_send_ammount.ForeColor = System.Drawing.Color.DarkCyan;
            this.txt_send_ammount.Location = new System.Drawing.Point(149, 191);
            this.txt_send_ammount.Name = "txt_send_ammount";
            this.txt_send_ammount.Size = new System.Drawing.Size(184, 24);
            this.txt_send_ammount.TabIndex = 129;
            this.txt_send_ammount.TextChanged += new System.EventHandler(this.txt_send_ammount_TextChanged);
            this.txt_send_ammount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_send_ammount_KeyPress);
            // 
            // txt_send_account
            // 
            this.txt_send_account.BackColor = System.Drawing.Color.DarkSlateGray;
            this.txt_send_account.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_send_account.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_send_account.ForeColor = System.Drawing.Color.DarkCyan;
            this.txt_send_account.Location = new System.Drawing.Point(35, 120);
            this.txt_send_account.Name = "txt_send_account";
            this.txt_send_account.Size = new System.Drawing.Size(288, 24);
            this.txt_send_account.TabIndex = 128;
            this.txt_send_account.TextChanged += new System.EventHandler(this.txt_send_account_TextChanged);
            this.txt_send_account.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_send_account_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Candara", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(163, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 19);
            this.label6.TabIndex = 127;
            this.label6.Text = "To";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Candara", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(17, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 19);
            this.label3.TabIndex = 126;
            this.label3.Text = "Send Money";
            // 
            // txt_account2
            // 
            this.txt_account2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.txt_account2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_account2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_account2.ForeColor = System.Drawing.Color.DarkCyan;
            this.txt_account2.Location = new System.Drawing.Point(35, 59);
            this.txt_account2.Name = "txt_account2";
            this.txt_account2.ReadOnly = true;
            this.txt_account2.Size = new System.Drawing.Size(288, 24);
            this.txt_account2.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(16, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 29);
            this.label5.TabIndex = 31;
            this.label5.Text = "Account  ID";
            // 
            // pan_hestory
            // 
            this.pan_hestory.BackColor = System.Drawing.Color.LightGray;
            this.pan_hestory.Controls.Add(this.label9);
            this.pan_hestory.Controls.Add(this.grd_user_history);
            this.pan_hestory.Location = new System.Drawing.Point(950, 138);
            this.pan_hestory.Name = "pan_hestory";
            this.pan_hestory.Size = new System.Drawing.Size(408, 438);
            this.pan_hestory.TabIndex = 131;
            this.pan_hestory.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.LightGray;
            this.label9.Font = new System.Drawing.Font("Candara", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label9.Location = new System.Drawing.Point(3, 402);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(155, 19);
            this.label9.TabIndex = 123;
            this.label9.Text = "👤Transaction History";
            // 
            // grd_user_history
            // 
            this.grd_user_history.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grd_user_history.BackgroundColor = System.Drawing.Color.LightGray;
            this.grd_user_history.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grd_user_history.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grd_user_history.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grd_user_history.DefaultCellStyle = dataGridViewCellStyle2;
            this.grd_user_history.GridColor = System.Drawing.Color.SeaGreen;
            this.grd_user_history.Location = new System.Drawing.Point(3, 5);
            this.grd_user_history.Name = "grd_user_history";
            this.grd_user_history.ReadOnly = true;
            this.grd_user_history.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Cornsilk;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grd_user_history.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grd_user_history.RowHeadersVisible = false;
            this.grd_user_history.Size = new System.Drawing.Size(402, 377);
            this.grd_user_history.TabIndex = 0;
            this.grd_user_history.VirtualMode = true;
            // 
            // pic_history
            // 
            this.pic_history.BackColor = System.Drawing.Color.SteelBlue;
            this.pic_history.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_history.Image = global::bankappdatabase.Properties.Resources.Screenshot_2025_04_30_184716_removebg_preview;
            this.pic_history.Location = new System.Drawing.Point(699, 255);
            this.pic_history.Name = "pic_history";
            this.pic_history.Size = new System.Drawing.Size(232, 265);
            this.pic_history.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_history.TabIndex = 0;
            this.pic_history.TabStop = false;
            this.pic_history.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pan_money_send
            // 
            this.pan_money_send.BackColor = System.Drawing.Color.SteelBlue;
            this.pan_money_send.BackgroundImage = global::bankappdatabase.Properties.Resources.Screenshot_2025_04_30_090246_removebg_preview;
            this.pan_money_send.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pan_money_send.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pan_money_send.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pan_money_send.Location = new System.Drawing.Point(400, 255);
            this.pan_money_send.Name = "pan_money_send";
            this.pan_money_send.Size = new System.Drawing.Size(235, 267);
            this.pan_money_send.TabIndex = 126;
            this.pan_money_send.DoubleClick += new System.EventHandler(this.pan_money_send_DoubleClick);
            // 
            // User_dash_board
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1301, 654);
            this.Controls.Add(this.pan_hestory);
            this.Controls.Add(this.pic_history);
            this.Controls.Add(this.pan__send_dash);
            this.Controls.Add(this.pan_balance);
            this.Controls.Add(this.pan_money_send);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.user_ACCOUNT);
            this.Controls.Add(this.txt_user_account_id);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_user_name);
            this.Controls.Add(this.panel1);
            this.Name = "User_dash_board";
            this.Text = "User_dash_board";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pan_balance.ResumeLayout(false);
            this.pan_balance.PerformLayout();
            this.pan__send_dash.ResumeLayout(false);
            this.pan__send_dash.PerformLayout();
            this.pan_hestory.ResumeLayout(false);
            this.pan_hestory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd_user_history)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_history)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_user_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label user_ACCOUNT;
        private System.Windows.Forms.TextBox txt_user_account_id;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel pan_money_send;
        private System.Windows.Forms.Label lab_ammount;
        private System.Windows.Forms.Panel pan_balance;
        private System.Windows.Forms.Panel pan__send_dash;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_account2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_send;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_send_ammount;
        private System.Windows.Forms.TextBox txt_send_account;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_send_name;
        private System.Windows.Forms.PictureBox pic_history;
        private System.Windows.Forms.Panel pan_hestory;
        private System.Windows.Forms.DataGridView grd_user_history;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button btn_account;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}