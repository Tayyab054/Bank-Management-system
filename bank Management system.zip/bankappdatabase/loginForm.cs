﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace bankappdatabase
{
    public partial class loginForm : Form
    {
        List<Account> account;
        public loginForm()
        {
            account = AccountDataBase.getAccountList();
            InitializeComponent();
           
        }
        private void btn_signUp_Click(object sender, EventArgs e)
        {
            SignUp_name s = new SignUp_name();
            s.Show();
            this.Hide();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_user_id.Text==""||txt_user_password.Text=="")
            {
                MessageBox.Show("fill All field");
                return;
            }
            bool login = false;

            for (int i = 0; i < account.Count; i++)
            {
                if (txt_user_id.Text == account[i].GetUser_id().ToString() &&
                    txt_user_password.Text == account[i].getPassword())                    
                {
                    login = true;
                    break;
                }           
            }
            int id = Convert.ToInt32(txt_user_id.Text);
            
            Account a = new Account();
            a.setuser_id(Convert.ToInt32( txt_user_id.Text));        
            if (login)
            {

               User_dash_board d = new User_dash_board(a);
                d.Show();
                this.Hide();
            }          
            else
            {
                MessageBox.Show("Invalid User");          
            }
        } 
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (txt_user_password.PasswordChar == '\0')
            {
                txt_user_password.PasswordChar = '*';
                pic_hide.Visible = true;
               // this.Hide(); ;
            }
            else
            {
                txt_user_password.PasswordChar = '\0';
                pic_hide.Visible =false;
               // this.Show();
            }
        }
        private void label6_Click(object sender, EventArgs e)
        {
            Reset_Password r = new Reset_Password(account);
            r.Show();
            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (txt_user_password.PasswordChar == '\0')
            {
                txt_user_password.PasswordChar = '*';
                pic_show.Visible = false;
              //  this.Show();
            }
            else
            {
                txt_user_password.PasswordChar = '\0';
                pic_show.Visible = true;
                pic_hide.Visible = false;
            }                                    
        }
      

    }
}
