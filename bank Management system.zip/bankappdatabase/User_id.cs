﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace bankappdatabase
{
    public partial class User_id : Form
    {
        private Account account;

        public User_id(Account a)
        {
            InitializeComponent();
            this.account = a;
            load();
        }

        private void txt_cnic_TextChanged(object sender, EventArgs e)
        {

        }
        private void load()
        {
            int id =Convert.ToInt32( AccountDataBase.getId());
                lab_account_id.Text =Convert.ToString(id);
                account.setuser_id(id);
         
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            SignUp_com_information s = new SignUp_com_information(account);
            s.Show();
            this.Hide();
        }

        private void User_id_Load(object sender, EventArgs e)
        {

        }
    }
}
