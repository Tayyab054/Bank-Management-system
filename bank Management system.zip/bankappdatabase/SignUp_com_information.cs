﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.IO;

namespace bankappdatabase
{
    
    public partial class SignUp_com_information : Form
    {
        private Account acc;
       
        public SignUp_com_information(Account a)
        {
            this.acc = a;
           
            InitializeComponent();
          
            load();
          
        }

        private void SignUp_com_information_Load(object sender, EventArgs e)
        {

        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if(!check_service.Checked)
            {
                MessageBox.Show("Please check Terms And services");
                return;
            }
            Image im=acc.GetImage();
            byte[] imagedata;
            MemoryStream ms = new MemoryStream();
            im.Save(ms, im.RawFormat);
           imagedata= ms.ToArray();
            int id = Convert.ToInt32(txt_user_id.Text);
            double balance = acc.getbalance();
            AccountDataBase.Insert_data(id, txt_cnic.Text, txt_first_name.Text, txt_last_name.Text, txt_phone.Text, txt_email.Text, txt_gender.Text, txt_address.Text, txt_password.Text, imagedata, txt_city.Text, balance);
            if (true)
            {
                MessageBox.Show("✅ Account Create Succesfully ");
                loginForm l = new loginForm();
                l.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Error insert data");
                
            }

        }
        public void load()
        {
            pic_user.Image = acc.GetImage();
            txt_email.Text = acc.getEmail();
            txt_first_name.Text = acc.getFirst_name();
            txt_last_name.Text = acc.getLast_name();
            txt_address.Text = acc.getAddress();
            txt_address.Text = acc.getAddress();
            txt_city.Text = acc.getCity();
            txt_cnic.Text = acc.getCnic();
            txt_gender.Text = acc.getGender();
            txt_password.Text = acc.getPassword();
            txt_phone.Text = acc.getPhone();
            txt_user_id.Text =Convert.ToString( acc.GetUser_id());

        }

        private void pic_user_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }
    }
}
