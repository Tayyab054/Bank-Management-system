﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankappdatabase
{
   public class Account
    {
        int user_id;
        string cnic;
        string first_name;
        string last_name;
        string email;
        string address;
        string city;
        string password;
        string gender;
        string phone;
        Image image;
        double balance;
        public Account()
        {
            user_id = 0;
            cnic = " ";
            first_name = " ";
            last_name = " ";
            email = " ";
            address = " ";
            city = " ";
            password = " ";
            gender = " ";
            phone = " ";
            image = null;
            balance = 0.0;
        }
        public Account(int user_id, string cnic, string first_name, string last_name, string email, string address, string city, string password, string gender, string phone,Image im, double balance)
        {
            this.user_id = user_id;
            this.cnic = cnic;
            this.first_name = first_name;
            this.last_name = last_name;
            this.email = email;
            this.address = address;
            this.city = city;
            this.password = password;
            this.gender = gender;
            this.phone = phone;
            this.image = im;
            this.balance = balance;
        }
       
        public void setuser_id(int u)
        {
            this.user_id = u;
        }
        public int GetUser_id()
        {
            return user_id; 
        }
        public void setCnic(string c) 
        {
            cnic = c;
        }
        public string getCnic()
        { 
            return cnic; 
        }
        public void setFirst_name(string f)
        { 
            first_name = f;
        }
        public string getFirst_name()
        { 
            return first_name;
        }
        public void setLast_name(string l) 
        {
            last_name = l; 
        }
        public string getLast_name() 
        {
            return last_name;
        }
        public void setEmail(string e) 
        { 
            email = e; 
        }
        public string getEmail() 
        { 
            return email; 
        }
        public void setAddress(string a) {
            address = a; 
        }
        public string getAddress() 
        { 
            return address;
        }
        public void setPassword(string p) 
        {
            password = p;
        }
        public string getPassword()
        { 
            return password;
        }
        public void setGender(string g)
        {
            gender = g;
        }
        public string getGender() 
        {
            return gender; 
        }
        public void setPhone(string p) 
        { 
            phone = p; 
        }
        public string getPhone() 
        { 
            return phone; 
        }
        public void setCity(string ci) 
        { 
            city = ci;
        }
        public string getCity() 
        { 
            return city;
        }
        public void setImage(Image img)
        {
            image = img;
        }
        public Image GetImage()
        {
            return image;
        }
        public void setbalance(double b)
        {
            balance = b;
        }
        public double getbalance()
        {
            return balance;
        }
           
    }
}
