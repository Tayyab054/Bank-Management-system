﻿namespace bankappdatabase
{
    partial class Admin_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_form));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_exit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_first_name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_account_id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txt_last_name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txt_gender = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txt_cnic = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.grd_user = new System.Windows.Forms.DataGridView();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pic_user = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_user)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_user)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PowderBlue;
            this.panel1.Controls.Add(this.btn_home);
            this.panel1.Controls.Add(this.btn_search);
            this.panel1.Controls.Add(this.txt_search);
            this.panel1.Controls.Add(this.btn_exit);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1300, 89);
            this.panel1.TabIndex = 27;
            // 
            // btn_home
            // 
            this.btn_home.BackgroundImage = global::bankappdatabase.Properties.Resources.Screenshot_2025_04_29_213219_removebg_preview;
            this.btn_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_home.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.btn_home.Location = new System.Drawing.Point(960, 31);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(90, 35);
            this.btn_home.TabIndex = 72;
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // btn_search
            // 
            this.btn_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_search.Font = new System.Drawing.Font("Georgia", 12.25F, System.Drawing.FontStyle.Bold);
            this.btn_search.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btn_search.Location = new System.Drawing.Point(693, 31);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(87, 29);
            this.btn_search.TabIndex = 71;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_money_Click);
            // 
            // txt_search
            // 
            this.txt_search.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txt_search.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_search.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txt_search.Location = new System.Drawing.Point(418, 34);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(295, 24);
            this.txt_search.TabIndex = 70;
            // 
            // btn_exit
            // 
            this.btn_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exit.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_exit.Location = new System.Drawing.Point(1093, 31);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(90, 35);
            this.btn_exit.TabIndex = 67;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(24, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Location = new System.Drawing.Point(119, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Global Bank ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel2.Location = new System.Drawing.Point(182, 149);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(295, 3);
            this.panel2.TabIndex = 30;
            // 
            // txt_first_name
            // 
            this.txt_first_name.BackColor = System.Drawing.SystemColors.Control;
            this.txt_first_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_first_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_first_name.ForeColor = System.Drawing.Color.DarkOrchid;
            this.txt_first_name.Location = new System.Drawing.Point(183, 120);
            this.txt_first_name.Name = "txt_first_name";
            this.txt_first_name.ReadOnly = true;
            this.txt_first_name.Size = new System.Drawing.Size(295, 24);
            this.txt_first_name.TabIndex = 29;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label5.Location = new System.Drawing.Point(30, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 29);
            this.label5.TabIndex = 28;
            this.label5.Text = "First Name";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel3.Location = new System.Drawing.Point(182, 210);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(295, 3);
            this.panel3.TabIndex = 72;
            // 
            // txt_account_id
            // 
            this.txt_account_id.BackColor = System.Drawing.SystemColors.Control;
            this.txt_account_id.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_account_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_account_id.ForeColor = System.Drawing.Color.Teal;
            this.txt_account_id.Location = new System.Drawing.Point(183, 181);
            this.txt_account_id.Name = "txt_account_id";
            this.txt_account_id.ReadOnly = true;
            this.txt_account_id.Size = new System.Drawing.Size(295, 24);
            this.txt_account_id.TabIndex = 71;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label2.Location = new System.Drawing.Point(30, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 29);
            this.label2.TabIndex = 70;
            this.label2.Text = "Account Id";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel4.Location = new System.Drawing.Point(688, 149);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(295, 3);
            this.panel4.TabIndex = 75;
            // 
            // txt_last_name
            // 
            this.txt_last_name.BackColor = System.Drawing.SystemColors.Control;
            this.txt_last_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_last_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_last_name.ForeColor = System.Drawing.Color.Teal;
            this.txt_last_name.Location = new System.Drawing.Point(689, 120);
            this.txt_last_name.Name = "txt_last_name";
            this.txt_last_name.ReadOnly = true;
            this.txt_last_name.Size = new System.Drawing.Size(295, 24);
            this.txt_last_name.TabIndex = 74;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label3.Location = new System.Drawing.Point(536, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 29);
            this.label3.TabIndex = 73;
            this.label3.Text = "Last Name";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel5.Location = new System.Drawing.Point(688, 210);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(295, 3);
            this.panel5.TabIndex = 78;
            // 
            // txt_phone
            // 
            this.txt_phone.BackColor = System.Drawing.SystemColors.Control;
            this.txt_phone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_phone.ForeColor = System.Drawing.Color.Teal;
            this.txt_phone.Location = new System.Drawing.Point(689, 181);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(295, 24);
            this.txt_phone.TabIndex = 77;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label4.Location = new System.Drawing.Point(536, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 29);
            this.label4.TabIndex = 76;
            this.label4.Text = "Phone";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel6.Location = new System.Drawing.Point(182, 271);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(295, 3);
            this.panel6.TabIndex = 81;
            // 
            // txt_email
            // 
            this.txt_email.BackColor = System.Drawing.SystemColors.Control;
            this.txt_email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_email.ForeColor = System.Drawing.Color.Teal;
            this.txt_email.Location = new System.Drawing.Point(183, 242);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(295, 24);
            this.txt_email.TabIndex = 80;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label6.Location = new System.Drawing.Point(30, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 29);
            this.label6.TabIndex = 79;
            this.label6.Text = "Email";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel7.Location = new System.Drawing.Point(688, 271);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(295, 3);
            this.panel7.TabIndex = 84;
            // 
            // txt_gender
            // 
            this.txt_gender.BackColor = System.Drawing.SystemColors.Control;
            this.txt_gender.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_gender.ForeColor = System.Drawing.Color.Teal;
            this.txt_gender.Location = new System.Drawing.Point(689, 242);
            this.txt_gender.Name = "txt_gender";
            this.txt_gender.Size = new System.Drawing.Size(295, 24);
            this.txt_gender.TabIndex = 83;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label7.Location = new System.Drawing.Point(536, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 29);
            this.label7.TabIndex = 82;
            this.label7.Text = "Gender";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel10.Location = new System.Drawing.Point(688, 381);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(295, 3);
            this.panel10.TabIndex = 96;
            // 
            // txt_balance
            // 
            this.txt_balance.BackColor = System.Drawing.SystemColors.Control;
            this.txt_balance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_balance.ForeColor = System.Drawing.Color.Teal;
            this.txt_balance.Location = new System.Drawing.Point(689, 352);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.ReadOnly = true;
            this.txt_balance.Size = new System.Drawing.Size(295, 24);
            this.txt_balance.TabIndex = 95;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label10.Location = new System.Drawing.Point(536, 355);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 29);
            this.label10.TabIndex = 94;
            this.label10.Text = "Balance";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel11.Location = new System.Drawing.Point(688, 320);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(295, 3);
            this.panel11.TabIndex = 93;
            // 
            // txt_city
            // 
            this.txt_city.BackColor = System.Drawing.SystemColors.Control;
            this.txt_city.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_city.ForeColor = System.Drawing.Color.Teal;
            this.txt_city.Location = new System.Drawing.Point(689, 291);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(295, 24);
            this.txt_city.TabIndex = 92;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label11.Location = new System.Drawing.Point(536, 294);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 29);
            this.label11.TabIndex = 91;
            this.label11.Text = "City";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel12.Location = new System.Drawing.Point(182, 381);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(295, 3);
            this.panel12.TabIndex = 90;
            // 
            // txt_cnic
            // 
            this.txt_cnic.BackColor = System.Drawing.SystemColors.Control;
            this.txt_cnic.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_cnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_cnic.ForeColor = System.Drawing.Color.Teal;
            this.txt_cnic.Location = new System.Drawing.Point(183, 352);
            this.txt_cnic.Name = "txt_cnic";
            this.txt_cnic.ReadOnly = true;
            this.txt_cnic.Size = new System.Drawing.Size(295, 24);
            this.txt_cnic.TabIndex = 89;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label12.Location = new System.Drawing.Point(30, 355);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 29);
            this.label12.TabIndex = 88;
            this.label12.Text = "Cnic";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panel13.Location = new System.Drawing.Point(182, 320);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(295, 3);
            this.panel13.TabIndex = 87;
            // 
            // txt_address
            // 
            this.txt_address.BackColor = System.Drawing.SystemColors.Control;
            this.txt_address.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.txt_address.ForeColor = System.Drawing.Color.Teal;
            this.txt_address.Location = new System.Drawing.Point(183, 291);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(295, 24);
            this.txt_address.TabIndex = 86;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Candara", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label13.Location = new System.Drawing.Point(30, 294);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 29);
            this.label13.TabIndex = 85;
            this.label13.Text = "Address";
            // 
            // grd_user
            // 
            this.grd_user.AllowUserToAddRows = false;
            this.grd_user.AllowUserToDeleteRows = false;
            this.grd_user.AllowUserToResizeColumns = false;
            this.grd_user.AllowUserToResizeRows = false;
            this.grd_user.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grd_user.BackgroundColor = System.Drawing.Color.Teal;
            this.grd_user.ColumnHeadersHeight = 30;
            this.grd_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.grd_user.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grd_user.EnableHeadersVisualStyles = false;
            this.grd_user.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.grd_user.Location = new System.Drawing.Point(89, 445);
            this.grd_user.MultiSelect = false;
            this.grd_user.Name = "grd_user";
            this.grd_user.ReadOnly = true;
            this.grd_user.RowHeadersVisible = false;
            this.grd_user.Size = new System.Drawing.Size(1094, 203);
            this.grd_user.StandardTab = true;
            this.grd_user.TabIndex = 98;
            this.grd_user.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd_user_CellContentClick);
            // 
            // btn_Update
            // 
            this.btn_Update.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btn_Update.Location = new System.Drawing.Point(1017, 341);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(97, 35);
            this.btn_Update.TabIndex = 99;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btn_delete.Location = new System.Drawing.Point(1143, 341);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(97, 35);
            this.btn_delete.TabIndex = 101;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pic_user
            // 
            this.pic_user.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_user.Location = new System.Drawing.Point(1046, 136);
            this.pic_user.Name = "pic_user";
            this.pic_user.Size = new System.Drawing.Size(178, 170);
            this.pic_user.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_user.TabIndex = 97;
            this.pic_user.TabStop = false;
            this.pic_user.Click += new System.EventHandler(this.pic_user_Click);
            // 
            // Admin_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 698);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.grd_user);
            this.Controls.Add(this.pic_user);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.txt_balance);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.txt_cnic);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.txt_gender);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.txt_phone);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.txt_last_name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txt_account_id);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txt_first_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Name = "Admin_form";
            this.Text = "Admin_form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admin_form_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_user)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_user)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_first_name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txt_account_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txt_last_name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txt_gender;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txt_cnic;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pic_user;
        private System.Windows.Forms.DataGridView grd_user;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btn_home;
    }
}