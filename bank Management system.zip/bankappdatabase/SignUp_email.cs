﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;

namespace bankappdatabase
{
    public partial class SignUp_email : Form
    {
       
        private string generatedOtp;
        Account a;
        public SignUp_email(Account ac)
        {
            this.a = ac;
            InitializeComponent();
           
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            loginForm l = new loginForm();
            l.ShowDialog();
            this.Close();
        }
    private void btn_send_Click(object sender, EventArgs e)
        {
            string email = txt_email.Text.Trim();

            if (string.IsNullOrEmpty(email) || !email.Contains("@"))
            {
                MessageBox.Show("Please enter a valid email.");
                return;
            }

            // Generate a random 6-digit OTP
           generatedOtp = GenerateOTP();

            // Send the OTP email
            SendOtpEmail(email, generatedOtp);
        }
        private string GenerateOTP()
        {
            Random rnd = new Random();
            return rnd.Next(100000, 999999).ToString();
        }
        private void SendOtpEmail(string recipientEmail, string otp)
        {
            string useremail = txt_email.Text.Trim();
            if (string.IsNullOrEmpty(useremail) || !useremail.Contains("@"))
            {
                MessageBox.Show("Please enter a valid email.");
                return;
            }
         
           // string userEmail = txt_email.Text.Trim();
         //  generatedOtp = new Random().Next(100000, 999999).ToString();
            try
            {
                MailMessage message = new MailMessage();
                message.From = new MailAddress("khalidmehar202@gmail.com");
                message.To.Add(useremail);
                message.Subject = "Global Bank OTP Code";
                message.Body = $" OTP is: {generatedOtp}\n";

                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.Credentials = new NetworkCredential("khalidmehar202@gmail.com", "xxow wbeu mfdb ncnd");
                smtp.EnableSsl = true;
                smtp.Send(message);
                txt_email.ReadOnly = true;
                MessageBox.Show("OTP sent successfully!");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to send OTP: " + ex.Message);
            }
        }
       

        private void btn_next_Click(object sender, EventArgs e)
        {
            if (txt_otp.Text.Trim() == generatedOtp)
            {
                MessageBox.Show("✅ OTP Verified!");
                
                a.setEmail(txt_email.Text);
                signUp_Basic_information b = new signUp_Basic_information(a);
                b.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("❌ Invalid OTP");
                
            }
           
        }

        private void SignUp_email_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txt_email_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
