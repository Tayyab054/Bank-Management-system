﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OracleClient;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Collections;

namespace bankappdatabase
{
    public partial class User_dash_board : Form
    {
        Account acc;
        List<Account> account;
      Account tosendaccount = new Account();


        public User_dash_board(Account a)
        {
            account = AccountDataBase.getAccountList();
           tosendaccount = new Account();
            this.acc = a;         
            InitializeComponent();
            curruntload();
            history();
        }
        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        public void curruntload()
        {
            if (acc.GetUser_id() != 1000 && acc.getPassword() != "Tayyab")
            {
                btn_account.Hide(); ;
            }
            else
            {
                btn_account.Show();
            }
            AccountDataBase Cr = new AccountDataBase();
            Account Cacc= Cr.crunntload(acc.GetUser_id());
            txt_user_account_id.Text = Convert.ToString(Cacc.GetUser_id());
            txt_user_name.Text = Cacc.getFirst_name().ToString() + " " + Cacc.getLast_name().ToString();
            lab_ammount.Text = Cacc.getbalance().ToString();
            txt_account2.Text = Convert.ToString(Cacc.GetUser_id());

        }    

        private void pan_money_send_DoubleClick(object sender, EventArgs e)
        {
            txt_send_account.Text = " ";
            txt_send_ammount.Text = " ";
            pan__send_dash.Visible = !pan__send_dash.Visible;
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (pan_hestory.Visible)
            {
                pan_hestory.Visible = false;
            }
            else
            {
                pan_hestory.Visible = true;
            }
        }
        private void txt_send_account_TextChanged(object sender, EventArgs e)
        {

            for (int i = 0; i < account.Count; i++)
            {
                if (string.IsNullOrWhiteSpace(txt_send_account.Text))
                {
                    return;
                }
                else if (account[i].GetUser_id() == Convert.ToInt32(txt_send_account.Text))
                {
                    txt_send_name.Text = account[i].getFirst_name() + " " + account[i].getLast_name();
                    tosendaccount.setuser_id(account[i].GetUser_id());
                    break;
                }

            }

        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_send_account.Text) || string.IsNullOrWhiteSpace(txt_send_ammount.Text))
            {
                MessageBox.Show("Please Enter All Field");
                return;
            }     
            if (txt_send_account.Text.Trim() != tosendaccount.GetUser_id().ToString())
            {
                    MessageBox.Show("User_id Invalid");
                    return;
            }            
            if (Convert.ToInt32(txt_send_ammount.Text) > Convert.ToInt32(lab_ammount.Text))
            {
                MessageBox.Show("Enter less Ammount Than Balance");
                return;
            }
            DialogResult result = MessageBox.Show("Are you sure you want to Send?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);

            if (result == DialogResult.OK)
            {
                int currunt_id = Convert.ToInt32(txt_account2.Text);
                int tosent_id = Convert.ToInt32(txt_send_account.Text);
                int balance = Convert.ToInt32(txt_send_ammount.Text);
                AccountDataBase.sendmoney(currunt_id, tosent_id,balance);
                if (true)
                {
                    MessageBox.Show("Send Succefully");
                    curruntload();
                    txt_send_ammount.Text = " ";
                    txt_send_name.Text = " ";
                    txt_send_account.Text = " ";
                    history();
                }
                else
                {
                    MessageBox.Show("Invalid Account");
                }
            }
            else
            {
                return;
            }
                

        }

        private void txt_send_ammount_TextChanged(object sender, EventArgs e)
        {

        }
        public void history()
        {
            {
               List<Transaction_history> history= AccountDataBase.History(acc.GetUser_id());
                DataTable dt = new DataTable();
                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("ID", typeof(int));
                dt.Columns.Add("Time", typeof(DateTime));
                dt.Columns.Add("Ammount", typeof(int));
                for (int i = 0; i < history.Count; i++)
                {
                    dt.Rows.Add(
                        history[i].getsendname(),
                         history[i].getsendid(),
                         history[i].getdate(),
                         history[i].getammount()
                    );
                }
                grd_user_history.DataSource = dt;
            }        
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            loginForm l = new loginForm();
            l.Show();
            this.Hide();
        }

        private void btn_account_Click(object sender, EventArgs e)
        {
            Admin_form a = new Admin_form();
            a.Show();
            this.Hide();
        }

        private void txt_send_account_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow control keys and digits only
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Block the key
            }
        }
        private void txt_send_ammount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Block the key
            }
        }
    }
}