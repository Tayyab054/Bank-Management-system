﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankappdatabase
{
    public partial class User_dash_board : Form
    {
        Account acc;
        public string ConnectionString = "Data Source=(DESCRIPTION=" + "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" + "(CONNECT_DATA=(SERVICE_NAME=XE)));" + "User id=bank;Password=123;";
        List<Account> account;
        Account sendaccount = new Account();

        public User_dash_board(Account a, List<Account> ac)
        {
           account = new List<Account>();
            sendaccount = new Account();
            this.acc = a;
            InitializeComponent();
            loadlist();
            curruntload();
            history();
         
           
        }
        private void loadlist()
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "select *from account";
                OracleCommand cmd = new OracleCommand(query, conn);
                OracleDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Account ac = new Account();
                    ac.setuser_id(Convert.ToInt32(reader["user_id"]));
                    ac.setbalance(Convert.ToInt32(reader["balance"]));
                    ac.setFirst_name(reader["first_name"].ToString());
                    ac.setLast_name(reader["last_name"].ToString());
                    account.Add(ac);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to fetch data");
            }

        }
        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

      
        public void curruntload()
        {
            if (acc.GetUser_id() !=1000 && acc.getPassword() !="Tayyab")
            {
                btn_account.Hide(); ;
            }
            else
            {
                btn_account.Show();
            }
            OracleConnection conn = new OracleConnection(ConnectionString);
            conn.Open();
            string query="select first_name,last_name,balance From Account where user_id="+acc.GetUser_id()+"";
            OracleCommand cmd = new OracleCommand(query,conn);
            OracleDataReader reader = cmd.ExecuteReader();
           if(reader.Read())
            {
                acc.setbalance(Convert.ToInt32(reader["balance"]));
                acc.setFirst_name(reader["First_name"].ToString());
                acc.setLast_name(reader["Last_name"].ToString());
                txt_user_account_id.Text = Convert.ToString(acc.GetUser_id());
                txt_user_name.Text = acc.getFirst_name().ToString()+" "+acc.getLast_name().ToString();
                lab_ammount.Text = acc.getbalance().ToString();
                txt_account2.Text = Convert.ToString(acc.GetUser_id());
              
            }
        }      
     
        private void lab_ammount_Click(object sender, EventArgs e)
        {
          
        }

        private void pan_money_send_DoubleClick(object sender, EventArgs e)
        {
            txt_send_account.Text = " ";
            txt_send_ammount.Text = " ";
            pan__send_dash.Visible = !pan__send_dash.Visible;
           
        }
      

        private void pan_money_send_Paint(object sender, PaintEventArgs e)
        {
        
        }

        private void pan__send_dash_Paint(object sender, PaintEventArgs e)
        {

        }

        private void slideTimer_Tick_1(object sender, EventArgs e)
        {
           
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pan_hestory.Visible = !pan_hestory.Visible;
        }

        private void txt_send_account_TextChanged(object sender, EventArgs e)
        {
          
            for (int i = 0; i < account.Count; i++)
            {
                if (string.IsNullOrWhiteSpace(txt_send_account.Text))
                {
                    return;
                }
                else if (account[i].GetUser_id() ==Convert.ToInt32(txt_send_account.Text))
                {
                    txt_send_name.Text = account[i].getFirst_name() + " " + account[i].getLast_name();
                    sendaccount.setuser_id(account[i].GetUser_id());
                    break;
                }
               
            }
         
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            int inputammount = Convert.ToInt32(txt_send_ammount.Text);
            if(inputammount> Convert.ToInt32( lab_ammount.Text))
            {
                MessageBox.Show("Enter less Ammount Than Balance");
                return;
            }
            else 
            {
                sendaccount.setbalance(inputammount);
            }
           
            
            try
            {               
                string currentDateTime = DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss");
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = " Insert into BANK_TRANSACTION (CRUNNT_ACCOUNT_ID,REC_ACCOUNT_ID,TIME,REC_AMMOUNT) values(" + acc.GetUser_id()+","+sendaccount.GetUser_id()+ ", TO_DATE('" +currentDateTime + "', 'DD-MON-YYYY HH24:MI:SS')," + sendaccount.getbalance()+ ")";
                OracleCommand cmd = new OracleCommand(query, conn);
                string sendquery = "Update account set balance=balance-" + sendaccount.getbalance() + " where user_id=" + acc.GetUser_id() + "";
                OracleCommand sendcmd = new OracleCommand(sendquery, conn); 
                string recivequery="Update account set balance=balance+"+sendaccount.getbalance()+" where user_id="+sendaccount.GetUser_id()+"";
                OracleCommand recivecmd = new OracleCommand(recivequery, conn);
                DialogResult result = MessageBox.Show("Are you sure you want to Send?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);

                if (result == DialogResult.OK)
                {
                    cmd.ExecuteNonQuery();
                    sendcmd.ExecuteNonQuery();
                    recivecmd.ExecuteNonQuery();
                    MessageBox.Show("Send Succefully");
                    curruntload();
                    txt_send_ammount.Text = " ";
                    txt_send_name.Text = " ";
                    txt_send_account.Text = " ";
                    history();
                }
                else
                {
                    return;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error To send" + ex);
            }

        }

        private void txt_send_ammount_TextChanged(object sender, EventArgs e)
        {
           
        }
        public void history()
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "SELECT a.First_name || ' ' || a.Last_name AS Name, " +
                               "bt.REC_ACCOUNT_ID, bt.TIME, bt.REC_AMMOUNT " +
                               "FROM BANK_TRANSACTION bt " +
                               "INNER JOIN account a ON a.USER_ID = bt.REC_ACCOUNT_ID " +
                               "WHERE bt.CRUNNT_ACCOUNT_ID = " + acc.GetUser_id();
                OracleCommand cmd = new OracleCommand(query, conn);
                OracleDataReader reader = cmd.ExecuteReader();
                List<Transaction_history> history = new List<Transaction_history>();
                while (reader.Read())
                {
                    Transaction_history h = new Transaction_history();
                    h.sendname(reader["Name"].ToString());
                    h.setsendid(Convert.ToInt32(reader["REC_ACCOUNT_ID"]));
                    h.setdate(Convert.ToDateTime(reader["TIME"]));
                    h.setammount(Convert.ToInt32(reader["REC_AMMOUNT"]));
                    history.Add(h);                  
                }
                DataTable dt = new DataTable();
                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("ID", typeof(int));
                dt.Columns.Add("Time", typeof(DateTime));
                dt.Columns.Add("Ammount", typeof(int));
                for (int i = 0; i < history.Count; i++)
                {
                    dt.Rows.Add(
                        history[i].getsendname(),
                         history[i].getsendid(),
                         history[i].getdate(),
                         history[i].getammount()                        
                    );
                }


                grd_user_history.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to load history"+ex);
            }

        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            loginForm l = new loginForm();
            l.Show();
            this.Hide();
        }

        private void btn_account_Click(object sender, EventArgs e)
        {
            Admin_form a = new Admin_form();
            a.Show();
            this.Hide();
        }

        private void txt_send_account_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow control keys and digits only
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Block the key
            }
        }
    }
}
