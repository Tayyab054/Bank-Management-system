﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace bankappdatabase
{

    public partial class SignUp_name : Form
    {
    
        public SignUp_name()
        {
            InitializeComponent();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            if (txt_first_name.Text ==string.Empty||txt_last_name.Text==string.Empty)
            {
                MessageBox.Show("All Field Fillout");
                return;
            }
            
            
                Account a = new Account();
                a.setFirst_name(txt_first_name.Text);
                a.setLast_name(txt_last_name.Text);
                SignUp_email s = new SignUp_email(a);              
                s.Show();
                this.Hide();
            
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            txt_first_name.Text = " ";
            txt_last_name.Text = " ";
            loginForm l = new loginForm();
            l.ShowDialog();
            this.Close();
        }

        private void SignUp_name_Load(object sender, EventArgs e)
        {

        }
    }
}
