﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankappdatabase
{
    internal class Transaction_history
    {
        public string sendName;
        public int sendId;
        public DateTime Time;
        public int Amount;
        public Transaction_history() { }    
        public Transaction_history(string sendName, int sendAccountId, DateTime time, int amount)
        {
            sendName = sendName;
           sendId = sendId;
            Time = time;
            Amount = amount;
        }
        public void sendname(string rec)
        {
            sendName = rec;
        }
        public string getsendname()
        {
            return sendName;
        }
        public void setsendid(int id)
        {
            sendId = id;
        }
        public int getsendid()
        {
            return sendId;
        }
        public void setdate(DateTime a)
        {
            Time = a;
        }
        public DateTime getdate()
        {
            return Time;
        }
        public void setammount(int a)
        {
            Amount = a;
        }
        public int getammount()
        {
            return Amount;
        }
    }
}
