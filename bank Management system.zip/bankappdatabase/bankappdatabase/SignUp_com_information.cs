﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.IO;

namespace bankappdatabase
{
    
    public partial class SignUp_com_information : Form
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" + "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" + "(CONNECT_DATA=(SERVICE_NAME=XE)));" + "User id=bank;Password=123;";

        private Account account;
       
        public SignUp_com_information(Account a)
        {
            this.account = a;
           
            InitializeComponent();
          
            load();
          
        }

        private void SignUp_com_information_Load(object sender, EventArgs e)
        {

        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if(!check_service.Checked)
            {
                MessageBox.Show("Please check Terms And services");
                return;
            }
            Image im=account.GetImage();
            byte[] imagedata;
            MemoryStream ms = new MemoryStream();
            im.Save(ms, im.RawFormat);
           imagedata= ms.ToArray();
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "Insert into Account (USER_ID,CNIC,FIRST_NAME,LAST_NAME,phone,email,gender,address,user_password,image,city,balance) values(" + account.GetUser_id() + ",'" + account.getCnic() + "','" + account.getFirst_name() + "','" + account.getLast_name() + "','" + account.getPhone() + "','" + account.getEmail() + "','" + account.getGender() + "','"+account.getAddress()+"','" + account.getPassword() + "',:img,'" + account.getCity() + "',"+account.getbalance()+")";
               
                OracleCommand cmd = new OracleCommand(query, conn);
                cmd.Parameters.Add(":img", OracleType.Blob).Value = imagedata;
                cmd.ExecuteNonQuery();
                MessageBox.Show("✅Insert Dat Succesfully");

                loginForm l = new loginForm();
                l.Show();
                this.Close();

            }
            catch(Exception ex)
            {
                MessageBox.Show("❌Error To Insert Data" + ex);
            }
        }
        public void load()
        {
            pic_user.Image = account.GetImage();
            txt_email.Text = account.getEmail();
            txt_first_name.Text = account.getFirst_name();
            txt_last_name.Text = account.getLast_name();
            txt_address.Text = account.getAddress();
            txt_address.Text = account.getAddress();
            txt_city.Text = account.getCity();
            txt_cnic.Text = account.getCnic();
            txt_gender.Text = account.getGender();
            txt_password.Text = account.getPassword();
            txt_phone.Text = account.getPhone();
            txt_user_id.Text =Convert.ToString( account.GetUser_id());

        }

        private void pic_user_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }
    }
}
