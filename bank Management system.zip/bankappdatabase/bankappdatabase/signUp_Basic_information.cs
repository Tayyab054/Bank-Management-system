﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankappdatabase
{
    public partial class signUp_Basic_information : Form
    {
        private Account account;


        public signUp_Basic_information(Account a)
        {
            InitializeComponent();
            this.account = a;
            txt_email.Text = account.getEmail();

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
       
        private void btn_next_Click(object sender, EventArgs e)
        {
            if (txt_address.Text ==" "|| txt_cnic.Text ==" " ||txt_conform_password.Text ==" " ||txt_email.Text ==" " || txt_password.Text ==" " || txt_phone.Text ==" " ||pic_user.Image ==null )
            {
                MessageBox.Show("Fill All Field");
                return;
            }
            if(txt_password.Text!=txt_conform_password.Text)
            {
                MessageBox.Show("Password not match");
                return;
            }
         
            account.setCnic(txt_cnic.Text);
            account.setAddress(txt_address.Text);
            account.setPassword(txt_password.Text);
            account.setCity(cmbo_city.Text);
            account.setPhone(txt_phone.Text);
            
            if (radio_male.Checked)
            {
                account.setGender(radio_male.Text);
            }
            else
            {
                account.setGender(radio_femail.Text);
            }
            User_id u = new User_id(account);
            u.Show();
            this.Hide();
           

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            loginForm l = new loginForm();
            l.Show();
            this.Close();
        }

        private void pic_user_Click(object sender, EventArgs e)
        {

        }

        private void signUp_Basic_information_Load(object sender, EventArgs e)
        {

        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Open Image";
            dialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Image selectedImage = Image.FromFile(dialog.FileName);
                pic_user.Image = selectedImage;
                account.setImage(selectedImage);



            }
        }
        bool ispsswordvisible;
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            ispsswordvisible = !ispsswordvisible;
            txt_password.PasswordChar = ispsswordvisible ? '\0' : '*';
            txt_conform_password.PasswordChar = ispsswordvisible ? '\0' : '*';
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {


            ispsswordvisible = !ispsswordvisible;
            txt_password.PasswordChar = ispsswordvisible ? '\0' : '*';
            txt_conform_password.PasswordChar = ispsswordvisible ? '\0' : '*';

        }
    }
}
