﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace bankappdatabase
{
    public partial class User_id : Form
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" + "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" + "(CONNECT_DATA=(SERVICE_NAME=XE)));" + "User id=bank;Password=123;";
        private Account account;

        public User_id(Account a)
        {
            InitializeComponent();
            this.account = a;
            load();
        }

        private void txt_cnic_TextChanged(object sender, EventArgs e)
        {

        }
        private void load()
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                String query = "Select Max(user_id)+1 from Account";
                OracleCommand cmd = new OracleCommand(query, conn);

                int id=Convert.ToInt32( cmd.ExecuteScalar());
                account.setuser_id(id);
                lab_account_id.Text =Convert.ToString( account.GetUser_id());
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error To load ID" + ex);
            }
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            SignUp_com_information s = new SignUp_com_information(account);
            s.Show();
            this.Hide();
        }
    }
}
