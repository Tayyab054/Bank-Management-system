﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankappdatabase
{
    public partial class Admin_form : Form
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" + "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" + "(CONNECT_DATA=(SERVICE_NAME=XE)));" + "User id=bank;Password=123;";
        List<Account> account = new List<Account>();
        Account accountUpdate = new Account();
      

        public Admin_form()
        {          
            InitializeComponent();
            account = new List<Account>();
            accountUpdate = new Account();
             setgetload();
        }

        private void Admin_form_Load(object sender, EventArgs e)
        {

        }
        public void setsingleobject()
        {
            accountUpdate.setuser_id(Convert.ToInt32(txt_account_id.Text));
            accountUpdate.setAddress(txt_address.Text);
            accountUpdate.setImage(pic_user.Image);
            accountUpdate.setCity(txt_city.Text);
            accountUpdate.setPhone(txt_phone.Text);
            accountUpdate.setEmail(txt_email.Text);
            accountUpdate.setGender(txt_gender.Text);
            accountUpdate.setImage(pic_user.Image);
           
        }
        private void btn_Update_Click(object sender, EventArgs e)
        {
             DialogResult result = MessageBox.Show("Are you sure you want to Update this account?","Confirm Update",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            setsingleobject();
            if (result != DialogResult.Yes) { return; }
            else
            {   Image im = accountUpdate.GetImage();
                byte[] imagedata;
                MemoryStream ms = new MemoryStream();
                im.Save(ms, im.RawFormat);
                imagedata = ms.ToArray();
                account.Add(accountUpdate);

                try
                {
                    OracleConnection conn = new OracleConnection(ConnectionString);
                    conn.Open();
                    string query = "Update account set address='" + accountUpdate.getAddress() + "',image=:img,city='" + accountUpdate.getCity() + "',phone='" + accountUpdate.getPhone() + "',email='" + accountUpdate.getEmail() + "',gender='" + accountUpdate.getGender() + "' where user_id=" + accountUpdate.GetUser_id() + " ";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(":img", OracleType.Blob).Value =imagedata;
                    cmd.ExecuteNonQuery();

                    setgetload();

                }
                catch (Exception EX)
                {
                    MessageBox.Show("Error To Update" + EX);
                }
            }
         
        }
        public void setgetload()
        {
            account.Clear();
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                String query = "Select *from Account";                
                OracleCommand cmd = new OracleCommand(query, conn);
                OracleDataReader reader = cmd.ExecuteReader();
              
                while (reader.Read())
                {
                  
                    Account acc = new Account();
                    acc.setuser_id(Convert.ToInt32(reader["USER_ID"]));
                    acc.setFirst_name(reader["FIRST_NAME"].ToString());
                    acc.setLast_name(reader["LAST_NAME"].ToString());
                    acc.setPhone(reader["PHONE"].ToString());
                    acc.setEmail(reader["EMAIL"].ToString());
                    acc.setGender(reader["GENDER"].ToString());
                    acc.setAddress(reader["ADDRESS"].ToString());
                    acc.setPassword(reader["USER_PASSWORD"].ToString());
                    //
                    byte[] imageBytes = (byte[])reader["IMAGE"];
                    MemoryStream ms = new MemoryStream(imageBytes);                        
                    Image img = Image.FromStream(ms);
                    acc.setImage(img); // Passing an Image,                
                    //
                    acc.setCity(reader["CITY"].ToString());
                    acc.setCnic(reader["CNIC"].ToString());
                    if (reader["BALANCE"] != DBNull.Value)
                    {
                        acc.setbalance(Convert.ToDouble(reader["BALANCE"]));
                    }
                    else
                    {
                        acc.setbalance(0.0);
                    }
                    account.Add(acc);
                    
    }
                //   grd_user.Rows.Clear();
                DataTable dt = new DataTable();
                dt.Columns.Add("USER_ID", typeof(int));
                dt.Columns.Add("FIRST_NAME", typeof(string));
                dt.Columns.Add("LAST_NAME", typeof(string));
                dt.Columns.Add("PHONE", typeof(string));
                dt.Columns.Add("EMAIL", typeof(string));
                dt.Columns.Add("GENDER", typeof(string));
                dt.Columns.Add("ADDRESS", typeof(string));
                dt.Columns.Add("CITY", typeof(string));
                dt.Columns.Add("CNIC", typeof(string));
                dt.Columns.Add("BALANCE", typeof(double));
                dt.Columns.Add("IMAGE", typeof(Image));
                
                for (int i = 0; i < account.Count; i++)
                { 
                    dt.Rows.Add(
                        account[i].GetUser_id(),
                         account[i].getFirst_name(),
                         account[i].getLast_name(),
                         account[i].getPhone(),
                         account[i].getEmail(),
                         account[i].getGender(),
                         account[i].getAddress(),
                         account[i].getCity(),
                         account[i].getCnic(),
                         account[i].getbalance(),
                         account[i].GetImage()
                    );
                }

   
                grd_user.DataSource = dt;


                


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to load" + ex);
            }
            
        }
    

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_account_id.Text))
            {
                MessageBox.Show("Please select a record to delete.");
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this account?","Confirm Delete",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            if (result != DialogResult.Yes) { return; }
            else
            {
                try
                {
                    OracleConnection conn = new OracleConnection(ConnectionString);
                    conn.Open();
                    string query = "DELETE FROM account WHERE user_id ="+accountUpdate.GetUser_id()+"";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    int rowaffected = cmd.ExecuteNonQuery();
                    if (rowaffected > 0)
                    {

                        MessageBox.Show("Delete Succeffully");
                        setgetload();
                    }
                    else
                    {
                        MessageBox.Show("Error To Delete");
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error to delet" + ex);
                }
            }

        }

        private void grd_user_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            pic_user.Image = null;
           
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = grd_user.Rows[e.RowIndex];
                txt_account_id.Text = selectedRow.Cells["user_id"].Value.ToString();
                txt_address.Text = selectedRow.Cells["address"].Value.ToString();
                txt_balance.Text = selectedRow.Cells["balance"].Value.ToString();
                txt_city.Text = selectedRow.Cells["city"].Value.ToString();
                txt_cnic.Text = selectedRow.Cells["cnic"].Value.ToString();
                txt_email.Text = selectedRow.Cells["email"].Value.ToString();
                txt_first_name.Text = selectedRow.Cells["first_name"].Value.ToString();
                txt_gender.Text = selectedRow.Cells["gender"].Value.ToString();
                txt_last_name.Text = selectedRow.Cells["last_name"].Value.ToString();
                txt_phone.Text = selectedRow.Cells["phone"].Value.ToString();
                pic_user.Image = (Image)selectedRow.Cells["IMAGE"].Value;
            }
            setsingleobject();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
      

        private void pic_user_Click(object sender, EventArgs e)
        {
           
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Open Image";
            dialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                pic_user.Image = Image.FromFile(dialog.FileName);
                           

            }
        }

        private void btn_money_Click(object sender, EventArgs e)//serch button
        {

            string keyword = txt_search.Text.Trim();

            // Try to get the DataView safely
            DataView dv = null;

            if (grd_user.DataSource is DataTable)
            {
                dv = ((DataTable)grd_user.DataSource).DefaultView;
            }
            else if (grd_user.DataSource is DataView)
            {
                dv = (DataView)grd_user.DataSource;
            }


            if (string.IsNullOrEmpty(keyword))
            {
                dv.RowFilter = ""; // Clear filter
            }
            else
            {
                // Apply filter (case-insensitive match)
                dv.RowFilter = $"FIRST_NAME LIKE '%{keyword}%' " +
                               $"OR LAST_NAME LIKE '%{keyword}%' " +
                               $"OR CNIC LIKE '%{keyword}%' " +
                               $"OR PHONE LIKE '%{keyword}%' " +
                               $"OR Convert(USER_ID, 'System.String') LIKE '%{keyword}%'";
            }

            grd_user.DataSource = dv;

        }

        private void btn_home_Click(object sender, EventArgs e)
        {
          
            loginForm l = new loginForm();
            l.Show();
            this.Close();
        }
    }
}
