﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankappdatabase
{
    public partial class Reset_Password : Form
    {
        public string ConnectionString = "Data Source=(DESCRIPTION=" + "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" + "(CONNECT_DATA=(SERVICE_NAME=XE)));" + "User id=bank;Password=123;";

        List<Account> account;
        Account a = new Account();
        public Reset_Password(List<Account> ac)
        {
            a = new Account();
            this.account = ac;
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            loginForm l = new loginForm();
            l.Show();
            this.Close();
        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_password.Text != txt_conform_password.Text)
            {
                MessageBox.Show("Password Not Match By conform Password");
                return;   
            }
            bool found=false;
            for(int i = 0; i < account.Count; i++)
            {
                if(account[i].GetUser_id() ==Convert.ToInt32(txt_user_id.Text))
                {
                   
                    a.setuser_id(account[i].GetUser_id());
                    a.setPassword(txt_password.Text);
                    found = true;
                    break;
                }
            }
            if (found)
            {
                try
                {
                    OracleConnection conn = new OracleConnection(ConnectionString);
                    conn.Open();
                    string query="update Account set user_password='"+a.getPassword()+"' where user_id="+a.GetUser_id()+"";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Password Update");
                    loginForm l = new loginForm();
                    l.Show();
                    this.Close();
                }
                catch(Exception ex)
                {

                    MessageBox.Show("Error To Update Password"+ex);
                }
               }

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        bool ispasswordvisible;
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            ispasswordvisible = !ispasswordvisible;
            txt_conform_password.PasswordChar = ispasswordvisible ? '\0' : '*';
            txt_password.PasswordChar = ispasswordvisible ? '\0' : '*';
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ispasswordvisible = !ispasswordvisible;
            txt_conform_password.PasswordChar = ispasswordvisible ? '\0' : '*';
            txt_password.PasswordChar = ispasswordvisible ? '\0' : '*';
        }

        private void Reset_Password_Load(object sender, EventArgs e)
        {

        }
    }
}
