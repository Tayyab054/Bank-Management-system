﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace bankappdatabase
{
    public partial class loginForm : Form
    {

        public string ConnectionString = "Data Source=(DESCRIPTION=" + "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" + "(CONNECT_DATA=(SERVICE_NAME=XE)));" + "User id=bank;Password=123;";
        List<Account> account;

        public loginForm()
        {
            account = new List<Account>();
            InitializeComponent();
            load();
            
        }

        private void btn_signUp_Click(object sender, EventArgs e)
        {
            SignUp_name s = new SignUp_name();
            s.Show();
            this.Hide();


        }

        private void btn_login_Click(object sender, EventArgs e)
        {
          
            bool login = false;

            for (int i = 0; i < account.Count; i++)
            {
                if (txt_user_id.Text == account[i].GetUser_id().ToString() &&
                    txt_user_password.Text == account[i].getPassword())
                    
                {
                    login = true;
                    break;
                }             
                
            }
            int id = Convert.ToInt32(txt_user_id.Text);
            
            Account a = new Account();
            a.setuser_id(Convert.ToInt32( txt_user_id.Text));        
             if (login)
            {

                MessageBox.Show("Welcome!");
                User_dash_board d = new User_dash_board(a,account);
                d.Show();
                this.Hide();

            }
          
            else
            {
                MessageBox.Show("Invalid User");             


            }



        }
                                
             
        
        bool ispasswordvisible;
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            ispasswordvisible = !ispasswordvisible;
            txt_user_password.PasswordChar = ispasswordvisible ? '\0' : '*';
        }
        private void load()
        {
           
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "select *from account";
                OracleCommand cmd = new OracleCommand(query, conn);
                OracleDataReader reader = cmd.ExecuteReader();             
        
                while (reader.Read())
                {
                    Account acc = new Account();
                    acc.setuser_id(Convert.ToInt32( reader["user_id"]));
                    acc.setPassword(reader["user_password"].ToString());
                    acc.setbalance(Convert.ToInt32(reader["balance"]));
                    acc.setFirst_name(reader["first_name"].ToString());
                    acc.setLast_name(reader["last_name"].ToString());
                    account.Add(acc);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to fetch data");
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Reset_Password r = new Reset_Password(account);
            r.Show();
            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txt_user_password_Enter(object sender, EventArgs e)
        {
          
        }

        private void txt_user_id_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
