﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OracleClient;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Security.Principal;

namespace bankappdatabase
{
    public class AccountDataBase
    {
        private static string ConnectionString = "Data Source=(DESCRIPTION=" + "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" + "(CONNECT_DATA=(SERVICE_NAME=XE)));" + "User id=bank;Password=123;";

        public static List<Account> getAccountList()
        {
            List<Account> account = new List<Account>();
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                String query = "Select *from Account";
                OracleCommand cmd = new OracleCommand(query, conn);
                OracleDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Account acc = new Account();
                    acc.setuser_id(Convert.ToInt32(reader["USER_ID"]));
                    acc.setFirst_name(reader["FIRST_NAME"].ToString());
                    acc.setLast_name(reader["LAST_NAME"].ToString());
                    acc.setPhone(reader["PHONE"].ToString());
                    acc.setEmail(reader["EMAIL"].ToString());
                    acc.setGender(reader["GENDER"].ToString());
                    acc.setAddress(reader["ADDRESS"].ToString());
                    acc.setPassword(reader["USER_PASSWORD"].ToString());
                    //
                    byte[] imageBytes = (byte[])reader["IMAGE"];
                    MemoryStream ms = new MemoryStream(imageBytes);
                    Image img = Image.FromStream(ms);
                    acc.setImage(img); // Pass  Image,                
                    //
                    acc.setCity(reader["CITY"].ToString());
                    acc.setCnic(reader["CNIC"].ToString());
                    if (reader["BALANCE"] != DBNull.Value)
                    {
                        acc.setbalance(Convert.ToDouble(reader["BALANCE"]));
                    }
                    else
                    {
                        acc.setbalance(0.0);
                    }
                    account.Add(acc);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error To load" + ex);
            }
            return account;
        }
        public static bool deleteAccount(int account_id)
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "DELETE FROM account WHERE user_id =" + account_id + "";
                OracleCommand cmd = new OracleCommand(query, conn);
                int rowaffected = cmd.ExecuteNonQuery();
                if (rowaffected > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to delet" + ex);
                return false;
            }
        }
        public static bool uppdateuser(string add, byte[] image, string city, string phone, string email, string gender, double balance, int account_id)
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "Update account set address='" + add + "',image=:img,city='" + city + "',phone='" + phone + "',email='" + email + "',gender='" + gender + "',balance=" + balance + " where user_id=" + account_id + " ";
                OracleCommand cmd = new OracleCommand(query, conn);
                cmd.Parameters.Add(":img", OracleType.Blob).Value = image;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception EX)
            {
                MessageBox.Show("Error To Update" + EX);
                return false;
            }
        }
        public static bool ResetPassword(string password, int account_id)
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "update Account set user_password='" + password + "' where user_id=" + account_id + "";
                OracleCommand cmd = new OracleCommand(query, conn);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error To Update");
                return false;

            }
        }
        public static string getId()
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                String query = "Select Max(user_id)+1 from Account";
                OracleCommand cmd = new OracleCommand(query, conn);

                string id = cmd.ExecuteScalar().ToString();
                return id;
            }
            catch (Exception)
            {
                MessageBox.Show("Error To Assign ID");
                return "Error";
            }
        }
        public static bool Insert_data(int id, string cnic, string fname, string Lname, string phone, string email, string gender, string addrees, string password, byte[] imagedata, string city, double balance)
        {
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "Insert into Account (USER_ID,CNIC,FIRST_NAME,LAST_NAME,phone,email,gender,address,user_password,image,city,balance) values(" + id + ",'" + cnic + "','" + fname + "','" + Lname + "','" + phone + "','" + email + "','" + gender + "','" + addrees + "','" + password + "',:img,'" + city + "'," + balance + ")";

                OracleCommand cmd = new OracleCommand(query, conn);
                cmd.Parameters.Add(":img", OracleType.Blob).Value = imagedata;
                cmd.ExecuteNonQuery();
                return true;

            }
            catch (Exception ex)
            {           
                MessageBox.Show("❌Error To Insert Data" + ex);
                return false;
            }
        }
        public Account crunntload(int id)
        {
            Account Cacc = new Account();
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "select first_name,last_name,balance,user_id From Account where user_id=" + id + "";
                OracleCommand cmd = new OracleCommand(query, conn);
                OracleDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {

                    Cacc.setbalance(Convert.ToInt32(reader["balance"]));
                    Cacc.setuser_id(Convert.ToInt32(reader["User_id"]));
                    Cacc.setFirst_name(reader["First_name"].ToString());
                    Cacc.setLast_name(reader["Last_name"].ToString());

                }
                else
                {
                    MessageBox.Show("Error To load");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error To load" + ex);

            }
            return Cacc;
        }
        public static List<Transaction_history> History(int id)
        {
            List<Transaction_history> history = new List<Transaction_history>();
        
            try
            {
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = "SELECT a.First_name || ' ' || a.Last_name AS Name, " +
                               "bt.REC_ACCOUNT_ID, bt.TIME, bt.REC_AMMOUNT " +
                               "FROM BANK_TRANSACTION bt " +
                               "INNER JOIN account a ON a.USER_ID = bt.REC_ACCOUNT_ID " +
                               "WHERE bt.CRUNNT_ACCOUNT_ID = " + id+"order by time " ;
                OracleCommand cmd = new OracleCommand(query, conn);
                OracleDataReader reader = cmd.ExecuteReader();               
                while (reader.Read())
                {
                    Transaction_history h = new Transaction_history();
                    h.sendname(reader["Name"].ToString());
                    h.setsendid(Convert.ToInt32(reader["REC_ACCOUNT_ID"]));
                    h.setdate(Convert.ToDateTime(reader["TIME"]));
                    h.setammount(Convert.ToInt32(reader["REC_AMMOUNT"]));
                    history.Add(h);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error to Load History" + ex);
             
            }
            return history;
        }
        public static bool sendmoney(int crunt_user_id,int to_send_user_id,int to_send_balance)
        {
            try
            {
                string currentDateTime = DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss");
                OracleConnection conn = new OracleConnection(ConnectionString);
                conn.Open();
                string query = " Insert into BANK_TRANSACTION (CRUNNT_ACCOUNT_ID,REC_ACCOUNT_ID,TIME,REC_AMMOUNT) values(" + crunt_user_id + "," + to_send_user_id + ", TO_DATE('" + currentDateTime + "', 'DD-MON-YYYY HH24:MI:SS')," +to_send_balance+ ")";
                OracleCommand cmd = new OracleCommand(query, conn);
                string sendquery = "Update account set balance=balance-" + to_send_balance + " where user_id=" + crunt_user_id + "";
                OracleCommand sendcmd = new OracleCommand(sendquery, conn);
                string recivequery = "Update account set balance=balance+" + to_send_balance+ " where user_id=" + to_send_user_id + "";
                OracleCommand recivecmd = new OracleCommand(recivequery, conn);
             
                    cmd.ExecuteNonQuery();
                    sendcmd.ExecuteNonQuery();
                    recivecmd.ExecuteNonQuery();
                return true;
            
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error To send" + ex);

                return false;
            }
        
        }
    }
}


